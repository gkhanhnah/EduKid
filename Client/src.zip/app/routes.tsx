import { createBrowserRouter } from "react-router";
import { Login } from "./pages/Login";
import { TeacherDashboard } from "./pages/TeacherDashboard";
import { StudentManagement } from "./pages/StudentManagement";
import { BehaviorTracking } from "./pages/BehaviorTracking";
import { BehaviorHistory } from "./pages/BehaviorHistory";
import { Games } from "./pages/Games";
import { GamePlay } from "./pages/GamePlay";
import { AILessonGenerator } from "./pages/AILessonGenerator";
import { Messages } from "./pages/Messages";
import { ParentDashboard } from "./pages/ParentDashboard";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/teacher",
    Component: TeacherDashboard,
  },
  {
    path: "/students",
    Component: StudentManagement,
  },
  {
    path: "/behavior",
    Component: BehaviorTracking,
  },
  {
    path: "/behavior-history",
    Component: BehaviorHistory,
  },
  {
    path: "/games",
    Component: Games,
  },
  {
    path: "/games/:gameId",
    Component: GamePlay,
  },
  {
    path: "/ai-lesson",
    Component: AILessonGenerator,
  },
  {
    path: "/messages",
    Component: Messages,
  },
  {
    path: "/parent",
    Component: ParentDashboard,
  },
]);
