import { useState } from "react";
import { Sidebar } from "../components/Sidebar";
import { students } from "../data/mockData";
import { Calendar, Filter } from "lucide-react";
import { motion } from "motion/react";

interface HistoryRecord {
  id: string;
  studentName: string;
  studentAvatar: string;
  type: 'good' | 'bad' | 'sleepy' | 'active';
  timestamp: Date;
  note: string;
}

export function BehaviorHistory() {
  const [filterType, setFilterType] = useState<'all' | 'good' | 'bad' | 'sleepy' | 'active'>('all');
  
  // Mock history data
  const mockHistory: HistoryRecord[] = [
    { id: '1', studentName: 'Emma Wilson', studentAvatar: '👧', type: 'good', timestamp: new Date(2026, 2, 22, 9, 30), note: 'Helped classmate with assignment' },
    { id: '2', studentName: 'Liam Chen', studentAvatar: '👦', type: 'active', timestamp: new Date(2026, 2, 22, 9, 45), note: 'Participated actively in discussion' },
    { id: '3', studentName: 'Olivia Smith', studentAvatar: '👧', type: 'good', timestamp: new Date(2026, 2, 22, 10, 15), note: 'Completed all exercises correctly' },
    { id: '4', studentName: 'Noah Brown', studentAvatar: '👦', type: 'sleepy', timestamp: new Date(2026, 2, 22, 10, 30), note: 'Appeared tired during lesson' },
    { id: '5', studentName: 'Lucas Davis', studentAvatar: '👦', type: 'active', timestamp: new Date(2026, 2, 22, 11, 0), note: 'Asked great questions' },
    { id: '6', studentName: 'Sophia Garcia', studentAvatar: '👧', type: 'good', timestamp: new Date(2026, 2, 22, 11, 15), note: 'Excellent behavior in group work' },
    { id: '7', studentName: 'Mason Lee', studentAvatar: '👦', type: 'bad', timestamp: new Date(2026, 2, 22, 11, 30), note: 'Disrupted class, talked out of turn' },
    { id: '8', studentName: 'Isabella Taylor', studentAvatar: '👧', type: 'active', timestamp: new Date(2026, 2, 22, 13, 0), note: 'Led group presentation' },
  ];

  const filteredHistory = filterType === 'all' 
    ? mockHistory 
    : mockHistory.filter(record => record.type === filterType);

  const behaviorTypes = [
    { type: 'all', label: 'All', icon: '📋', color: 'bg-muted' },
    { type: 'good', label: 'Good', icon: '👍', color: 'bg-secondary' },
    { type: 'active', label: 'Active', icon: '⭐', color: 'bg-primary' },
    { type: 'sleepy', label: 'Sleepy', icon: '😴', color: 'bg-[#F59E0B]' },
    { type: 'bad', label: 'Bad', icon: '👎', color: 'bg-destructive' },
  ] as const;

  const getBehaviorStyle = (type: string) => {
    switch (type) {
      case 'good': return { bg: 'bg-secondary/10', text: 'text-secondary', icon: '👍' };
      case 'bad': return { bg: 'bg-destructive/10', text: 'text-destructive', icon: '👎' };
      case 'sleepy': return { bg: 'bg-[#F59E0B]/10', text: 'text-[#F59E0B]', icon: '😴' };
      case 'active': return { bg: 'bg-primary/10', text: 'text-primary', icon: '⭐' };
      default: return { bg: 'bg-muted', text: 'text-foreground', icon: '📋' };
    }
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="mb-2">Behavior History</h1>
            <p className="text-[1.125rem] text-muted-foreground">
              View and filter all behavior records
            </p>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-3xl p-6 shadow-lg border border-border mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Filter className="w-5 h-5 text-primary" />
              <h3>Filter by Type</h3>
            </div>
            <div className="flex flex-wrap gap-3">
              {behaviorTypes.map((behavior) => (
                <button
                  key={behavior.type}
                  onClick={() => setFilterType(behavior.type)}
                  className={`px-6 py-3 rounded-2xl transition-all ${
                    filterType === behavior.type
                      ? `${behavior.color} text-white shadow-lg`
                      : 'bg-muted text-foreground hover:bg-muted/70'
                  }`}
                >
                  <span className="text-[1.25rem] mr-2">{behavior.icon}</span>
                  {behavior.label}
                </button>
              ))}
            </div>
          </div>

          {/* Stats Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {behaviorTypes.slice(1).map((behavior, index) => {
              const count = mockHistory.filter(r => r.type === behavior.type).length;
              return (
                <motion.div
                  key={behavior.type}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-3xl p-6 shadow-lg border border-border"
                >
                  <div className="text-[2rem] mb-2">{behavior.icon}</div>
                  <h3 className="text-[2rem] mb-1">{count}</h3>
                  <p className="text-[0.9375rem] text-muted-foreground">{behavior.label}</p>
                </motion.div>
              );
            })}
          </div>

          {/* History Timeline */}
          <div className="bg-white rounded-3xl p-6 shadow-lg border border-border">
            <div className="flex items-center gap-3 mb-6">
              <Calendar className="w-5 h-5 text-primary" />
              <h3>Today's Records</h3>
            </div>
            
            <div className="space-y-4">
              {filteredHistory.map((record, index) => {
                const style = getBehaviorStyle(record.type);
                return (
                  <motion.div
                    key={record.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-start gap-4 p-5 rounded-2xl hover:bg-accent transition-all border border-transparent hover:border-primary/20"
                  >
                    {/* Timeline Dot */}
                    <div className="flex flex-col items-center">
                      <div className={`w-12 h-12 rounded-2xl ${style.bg} flex items-center justify-center text-[1.5rem]`}>
                        {style.icon}
                      </div>
                      {index < filteredHistory.length - 1 && (
                        <div className="w-0.5 h-12 bg-border mt-2" />
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <span className="text-[1.5rem]">{record.studentAvatar}</span>
                          <div>
                            <h4 className="text-[1rem]">{record.studentName}</h4>
                            <p className="text-[0.875rem] text-muted-foreground">
                              {record.timestamp.toLocaleTimeString('en-US', { 
                                hour: 'numeric', 
                                minute: '2-digit',
                                hour12: true 
                              })}
                            </p>
                          </div>
                        </div>
                        <div className={`px-4 py-2 rounded-full text-[0.875rem] ${style.bg} ${style.text}`}>
                          {record.type.charAt(0).toUpperCase() + record.type.slice(1)}
                        </div>
                      </div>
                      <p className="text-[0.9375rem] text-muted-foreground pl-11">{record.note}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {filteredHistory.length === 0 && (
              <div className="text-center py-12">
                <div className="text-[4rem] mb-4">📭</div>
                <p className="text-[1.125rem] text-muted-foreground">No records found for this filter</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
