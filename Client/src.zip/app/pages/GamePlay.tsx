import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { games } from "../data/mockData";
import { X, Star, Trophy, ArrowLeft } from "lucide-react";
import { motion } from "motion/react";
import confetti from "canvas-confetti";

export function GamePlay() {
  const { gameId } = useParams();
  const navigate = useNavigate();
  const game = games.find(g => g.id === gameId);
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [progress, setProgress] = useState(0);

  // Alphabet game state
  const [currentLetter, setCurrentLetter] = useState('A');
  const [options, setOptions] = useState<string[]>([]);

  useEffect(() => {
    if (gameId === 'alphabet') {
      generateAlphabetQuestion();
    }
  }, [gameId, level]);

  const generateAlphabetQuestion = () => {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const randomIndex = Math.floor(Math.random() * 26);
    const correctLetter = letters[randomIndex];
    setCurrentLetter(correctLetter);

    // Generate options
    const wrongLetters = [];
    while (wrongLetters.length < 3) {
      const wrongIndex = Math.floor(Math.random() * 26);
      const letter = letters[wrongIndex];
      if (letter !== correctLetter && !wrongLetters.includes(letter)) {
        wrongLetters.push(letter);
      }
    }
    
    const allOptions = [correctLetter, ...wrongLetters].sort(() => Math.random() - 0.5);
    setOptions(allOptions);
  };

  const handleAnswer = (selectedLetter: string) => {
    if (selectedLetter === currentLetter) {
      setScore(score + 10);
      setProgress(Math.min(progress + 20, 100));
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      
      if (progress + 20 >= 100) {
        setTimeout(() => {
          setLevel(level + 1);
          setProgress(0);
        }, 1000);
      } else {
        setTimeout(() => generateAlphabetQuestion(), 1000);
      }
    }
  };

  if (!game) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-[4rem] mb-4">🎮</div>
          <h2>Game not found</h2>
          <button 
            onClick={() => navigate('/games')}
            className="mt-6 bg-primary text-white px-6 py-3 rounded-2xl"
          >
            Back to Games
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E0E7FF] via-background to-[#FEF3C7] p-6">
      {/* Header */}
      <div className="max-w-4xl mx-auto mb-6">
        <div className="bg-white rounded-3xl p-6 shadow-lg border border-border">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate('/games')}
              className="p-3 hover:bg-accent rounded-2xl transition-all"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-[#F59E0B]" />
                <span className="text-[1.125rem]">Score: {score}</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-primary" />
                <span className="text-[1.125rem]">Level {level}</span>
              </div>
            </div>

            <button
              onClick={() => navigate('/games')}
              className="p-3 hover:bg-destructive/10 text-destructive rounded-2xl transition-all"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Progress Bar */}
          <div className="mt-6">
            <div className="w-full h-4 bg-muted rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-primary to-secondary"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <p className="text-center text-[0.875rem] text-muted-foreground mt-2">
              Level Progress: {progress}%
            </p>
          </div>
        </div>
      </div>

      {/* Game Content */}
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-3xl p-12 shadow-2xl border border-border text-center"
        >
          {/* Game Title */}
          <div className="mb-8">
            <div className="text-[5rem] mb-4">{game.icon}</div>
            <h2 className="text-[2rem]">{game.title}</h2>
            <p className="text-[1.125rem] text-muted-foreground mt-2">
              Click on the letter you hear!
            </p>
          </div>

          {/* Question */}
          {gameId === 'alphabet' && (
            <>
              <motion.div
                key={currentLetter}
                initial={{ scale: 0 }}
                animate={{ scale: 1, rotate: [0, 5, -5, 0] }}
                className="mb-12"
              >
                <div 
                  className="inline-block text-[8rem] p-12 rounded-[3rem] shadow-2xl cursor-pointer hover:scale-110 transition-all"
                  style={{ backgroundColor: `${game.color}20` }}
                >
                  {currentLetter}
                </div>
                <p className="text-[1.5rem] mt-6 text-muted-foreground">
                  Find the letter: <span style={{ color: game.color }}>{currentLetter}</span>
                </p>
              </motion.div>

              {/* Options */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
                {options.map((letter, index) => (
                  <motion.button
                    key={letter}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleAnswer(letter)}
                    className="text-[4rem] p-8 rounded-3xl shadow-lg hover:shadow-2xl transition-all border-4 border-transparent hover:border-primary"
                    style={{ backgroundColor: `${game.color}10` }}
                  >
                    {letter}
                  </motion.button>
                ))}
              </div>
            </>
          )}

          {/* Other game types placeholder */}
          {gameId !== 'alphabet' && (
            <div className="py-12">
              <div className="text-[6rem] mb-6">{game.icon}</div>
              <h3 className="text-[1.5rem] mb-4">Game Coming Soon!</h3>
              <p className="text-[1.125rem] text-muted-foreground mb-8">
                This game is currently under development
              </p>
              <button
                onClick={() => navigate('/games')}
                className="bg-primary text-white px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all"
              >
                Back to Games
              </button>
            </div>
          )}
        </motion.div>

        {/* Instructions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-6 bg-white rounded-3xl p-6 shadow-lg border border-border"
        >
          <h4 className="mb-3">How to Play:</h4>
          <ul className="text-[0.9375rem] text-muted-foreground space-y-2 list-disc list-inside">
            <li>Look at the large letter shown</li>
            <li>Click on the matching letter from the options below</li>
            <li>Each correct answer gives you 10 points</li>
            <li>Complete the progress bar to advance to the next level</li>
            <li>Have fun learning!</li>
          </ul>
        </motion.div>
      </div>
    </div>
  );
}
