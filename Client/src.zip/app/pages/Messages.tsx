import { useState } from "react";
import { Sidebar } from "../components/Sidebar";
import { conversations } from "../data/mockData";
import { Send, Image, Search, MoreVertical } from "lucide-react";
import { motion } from "motion/react";

interface Message {
  id: string;
  content: string;
  senderId: string;
  timestamp: Date;
  isOwn: boolean;
}

export function Messages() {
  const [selectedConversation, setSelectedConversation] = useState(conversations[0]);
  const [messageText, setMessageText] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  // Mock messages for selected conversation
  const mockMessages: Message[] = [
    {
      id: '1',
      content: "Hello Mrs. Anderson! How is Emma doing in class?",
      senderId: '1',
      timestamp: new Date(2026, 2, 22, 9, 0),
      isOwn: false
    },
    {
      id: '2',
      content: "Hello! Emma is doing wonderfully. She's very engaged in all activities.",
      senderId: 'teacher',
      timestamp: new Date(2026, 2, 22, 9, 15),
      isOwn: true
    },
    {
      id: '3',
      content: "That's great to hear! She really enjoyed the alphabet game yesterday.",
      senderId: '1',
      timestamp: new Date(2026, 2, 22, 9, 30),
      isOwn: false
    },
    {
      id: '4',
      content: "Yes! She scored 100% on it. I'm very proud of her progress this week. 🌟",
      senderId: 'teacher',
      timestamp: new Date(2026, 2, 22, 10, 0),
      isOwn: true
    },
    {
      id: '5',
      content: "Thank you for the update on Emma's progress!",
      senderId: '1',
      timestamp: new Date(2026, 2, 22, 10, 30),
      isOwn: false
    },
  ];

  const [messages] = useState<Message[]>(mockMessages);

  const handleSendMessage = () => {
    if (!messageText.trim()) return;
    // Add message logic here
    setMessageText("");
  };

  const filteredConversations = conversations.filter(conv =>
    conv.participantName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex overflow-hidden">
        {/* Conversations List */}
        <div className="w-96 bg-white border-r border-border flex flex-col">
          {/* Search */}
          <div className="p-6 border-b border-border">
            <h2 className="mb-4">Messages</h2>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search conversations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-background border border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          {/* Conversation List */}
          <div className="flex-1 overflow-auto">
            {filteredConversations.map((conversation) => (
              <motion.div
                key={conversation.id}
                whileHover={{ backgroundColor: '#F3F4F6' }}
                onClick={() => setSelectedConversation(conversation)}
                className={`p-5 border-b border-border cursor-pointer transition-all ${
                  selectedConversation.id === conversation.id ? 'bg-accent' : ''
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-[1.5rem] flex-shrink-0">
                    {conversation.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="text-[0.9375rem] truncate pr-2">{conversation.participantName}</h4>
                      {conversation.unreadCount > 0 && (
                        <div className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-[0.75rem] flex-shrink-0">
                          {conversation.unreadCount}
                        </div>
                      )}
                    </div>
                    <p className="text-[0.875rem] text-muted-foreground truncate mb-1">
                      {conversation.lastMessage}
                    </p>
                    <p className="text-[0.75rem] text-muted-foreground">
                      {conversation.lastMessageTime.toLocaleTimeString('en-US', { 
                        hour: 'numeric', 
                        minute: '2-digit',
                        hour12: true 
                      })}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col bg-background">
          {/* Chat Header */}
          <div className="bg-white border-b border-border p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-[1.5rem]">
                  {selectedConversation.avatar}
                </div>
                <div>
                  <h3>{selectedConversation.participantName}</h3>
                  <p className="text-[0.875rem] text-muted-foreground">Active now</p>
                </div>
              </div>
              <button className="p-3 hover:bg-accent rounded-2xl transition-all">
                <MoreVertical className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-auto p-6 space-y-4">
            {messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex ${message.isOwn ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-md px-6 py-4 rounded-3xl ${
                    message.isOwn
                      ? 'bg-primary text-white rounded-br-md'
                      : 'bg-white border border-border rounded-bl-md'
                  }`}
                >
                  <p className="text-[0.9375rem]">{message.content}</p>
                  <p className={`text-[0.75rem] mt-2 ${
                    message.isOwn ? 'text-white/70' : 'text-muted-foreground'
                  }`}>
                    {message.timestamp.toLocaleTimeString('en-US', { 
                      hour: 'numeric', 
                      minute: '2-digit',
                      hour12: true 
                    })}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Message Input */}
          <div className="bg-white border-t border-border p-6">
            <div className="flex items-end gap-4">
              <button className="p-4 hover:bg-accent rounded-2xl transition-all">
                <Image className="w-6 h-6 text-muted-foreground" />
              </button>
              
              <div className="flex-1">
                <textarea
                  placeholder="Type your message..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  rows={1}
                  className="w-full px-6 py-4 bg-background border border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                />
              </div>

              <button
                onClick={handleSendMessage}
                disabled={!messageText.trim()}
                className="p-4 bg-primary text-white rounded-2xl hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-6 h-6" />
              </button>
            </div>
            <p className="text-[0.75rem] text-muted-foreground mt-2 ml-16">
              Press Enter to send, Shift+Enter for new line
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
