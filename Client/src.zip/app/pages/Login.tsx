import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";

export function Login() {
  const navigate = useNavigate();
  const [userType, setUserType] = useState<'teacher' | 'parent'>('teacher');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (userType === 'teacher') {
      navigate('/teacher');
    } else {
      navigate('/parent');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E0E7FF] via-background to-[#FEF3C7] flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-5xl grid md:grid-cols-2 gap-8 items-center"
      >
        {/* Illustration Side */}
        <div className="text-center md:text-left">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2 }}
            className="text-[8rem] mb-6"
          >
            🎓
          </motion.div>
          <h1 className="text-[2.5rem] mb-4">
            Welcome to <span className="text-primary">ClassRoom</span>
          </h1>
          <p className="text-[1.125rem] text-muted-foreground">
            A friendly classroom management system for Grade 1 teachers and parents
          </p>
          <div className="flex gap-4 mt-6 text-[3rem] justify-center md:justify-start">
            <motion.span animate={{ rotate: [0, 10, -10, 0] }} transition={{ repeat: Infinity, duration: 2 }}>
              📚
            </motion.span>
            <motion.span animate={{ y: [0, -10, 0] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.2 }}>
              ✏️
            </motion.span>
            <motion.span animate={{ rotate: [0, -10, 10, 0] }} transition={{ repeat: Infinity, duration: 2, delay: 0.4 }}>
              🎨
            </motion.span>
          </div>
        </div>

        {/* Login Form */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-3xl shadow-2xl p-8"
        >
          <h2 className="text-center mb-6">Login to Your Account</h2>

          {/* User Type Selection */}
          <div className="flex gap-3 mb-6">
            <button
              type="button"
              onClick={() => setUserType('teacher')}
              className={`flex-1 py-4 rounded-2xl transition-all ${
                userType === 'teacher'
                  ? 'bg-primary text-white shadow-lg scale-105'
                  : 'bg-muted text-foreground'
              }`}
            >
              <div className="text-[2rem] mb-1">👨‍🏫</div>
              <div className="text-[0.9375rem]">Teacher</div>
            </button>
            <button
              type="button"
              onClick={() => setUserType('parent')}
              className={`flex-1 py-4 rounded-2xl transition-all ${
                userType === 'parent'
                  ? 'bg-primary text-white shadow-lg scale-105'
                  : 'bg-muted text-foreground'
              }`}
            >
              <div className="text-[2rem] mb-1">👨‍👩‍👧</div>
              <div className="text-[0.9375rem]">Parent</div>
            </button>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label htmlFor="email" className="block mb-2 text-foreground">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                placeholder="Enter your email"
                className="w-full px-5 py-4 bg-input-background border border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary"
                defaultValue={userType === 'teacher' ? 'teacher@school.com' : 'parent@email.com'}
              />
            </div>

            <div>
              <label htmlFor="password" className="block mb-2 text-foreground">
                Password
              </label>
              <input
                id="password"
                type="password"
                placeholder="Enter your password"
                className="w-full px-5 py-4 bg-input-background border border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary"
                defaultValue="password123"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-primary text-white py-4 rounded-2xl hover:bg-primary/90 transition-all shadow-lg hover:shadow-xl"
            >
              Login as {userType === 'teacher' ? 'Teacher' : 'Parent'}
            </button>
          </form>

          <p className="text-center text-[0.875rem] text-muted-foreground mt-6">
            Demo credentials are pre-filled. Just click Login!
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}
