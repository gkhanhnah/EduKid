import { useState } from "react";
import { motion } from "motion/react";
import { Calendar, MessageCircle, TrendingUp, Award, Clock, ArrowLeft } from "lucide-react";
import { Link } from "react-router";

export function ParentDashboard() {
  const [childName] = useState("Emma Wilson");

  const todayBehavior = [
    { type: 'good', icon: '👍', label: 'Good Behavior', count: 4, color: 'text-secondary' },
    { type: 'active', icon: '⭐', label: 'Active', count: 6, color: 'text-primary' },
    { type: 'sleepy', icon: '😴', label: 'Tired', count: 1, color: 'text-[#F59E0B]' },
    { type: 'bad', icon: '👎', label: 'Needs Attention', count: 0, color: 'text-destructive' },
  ];

  const recentActivities = [
    { time: '2:30 PM', activity: 'Completed Art & Crafts', icon: '🎨', color: 'bg-[#F59E0B]' },
    { time: '1:00 PM', activity: 'Story Time - Great participation!', icon: '📚', color: 'bg-primary' },
    { time: '11:00 AM', activity: 'Played Number Counting Game', icon: '🔢', color: 'bg-secondary' },
    { time: '10:00 AM', activity: 'Alphabet Learning - 100% Score', icon: '🔤', color: 'bg-[#8B5CF6]' },
    { time: '9:00 AM', activity: 'Morning Circle - Present', icon: '🌅', color: 'bg-[#06B6D4]' },
  ];

  const weeklyProgress = [
    { day: 'Mon', good: 8, active: 10 },
    { day: 'Tue', good: 10, active: 12 },
    { day: 'Wed', good: 7, active: 9 },
    { day: 'Thu', good: 9, active: 11 },
    { day: 'Fri', good: 11, active: 13 },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-secondary text-white p-8">
        <div className="max-w-7xl mx-auto">
          <Link to="/" className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-all">
            <ArrowLeft className="w-5 h-5" />
            Back to Login
          </Link>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[2rem] mb-2">Parent Dashboard</h1>
              <p className="text-[1.125rem] opacity-90">Welcome back! Here's how {childName} is doing</p>
            </div>
            <div className="w-24 h-24 rounded-3xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-[3rem]">
              👧
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {todayBehavior.map((item, index) => (
            <motion.div
              key={item.type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="text-[2.5rem] mb-2">{item.icon}</div>
              <h3 className={`text-[2rem] mb-1 ${item.color}`}>{item.count}</h3>
              <p className="text-[0.9375rem] text-muted-foreground">{item.label}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Today's Summary */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-3xl p-8 shadow-lg border border-border"
          >
            <div className="flex items-center gap-3 mb-6">
              <Calendar className="w-6 h-6 text-primary" />
              <h2>Today's Summary</h2>
            </div>

            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between p-4 rounded-2xl bg-secondary/10">
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-5 h-5 text-secondary" />
                  <span className="text-[0.9375rem]">Overall Behavior</span>
                </div>
                <span className="text-[1.125rem] text-secondary">Excellent</span>
              </div>
              
              <div className="flex items-center justify-between p-4 rounded-2xl bg-primary/10">
                <div className="flex items-center gap-3">
                  <Award className="w-5 h-5 text-primary" />
                  <span className="text-[0.9375rem]">Achievements</span>
                </div>
                <span className="text-[1.125rem] text-primary">3 Stars</span>
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl bg-accent">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-muted-foreground" />
                  <span className="text-[0.9375rem]">Attendance</span>
                </div>
                <span className="text-[1.125rem] text-secondary">✓ Present</span>
              </div>
            </div>

            <div className="pt-6 border-t border-border">
              <h4 className="mb-3">Teacher's Note</h4>
              <p className="text-[0.9375rem] text-muted-foreground p-4 bg-[#FEF3C7] rounded-2xl">
                "{childName} had an excellent day! She participated actively in all lessons and helped her classmates. Very proud of her progress! 🌟"
              </p>
            </div>
          </motion.div>

          {/* Weekly Progress Chart */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-3xl p-8 shadow-lg border border-border"
          >
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="w-6 h-6 text-primary" />
              <h2>Weekly Progress</h2>
            </div>

            <div className="flex items-end justify-between gap-3 h-64 mb-6">
              {weeklyProgress.map((day, index) => (
                <div key={day.day} className="flex-1 flex flex-col items-center gap-2">
                  <div className="flex flex-col gap-1 w-full">
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${day.active * 8}px` }}
                      transition={{ delay: 0.6 + index * 0.1 }}
                      className="bg-primary rounded-t-xl w-full"
                      title={`Active: ${day.active}`}
                    />
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${day.good * 8}px` }}
                      transition={{ delay: 0.6 + index * 0.1 }}
                      className="bg-secondary rounded-b-xl w-full"
                      title={`Good: ${day.good}`}
                    />
                  </div>
                  <span className="text-[0.875rem] text-muted-foreground">{day.day}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-center gap-6 text-[0.875rem]">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-primary" />
                <span>Active</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-secondary" />
                <span>Good Behavior</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Recent Activities */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white rounded-3xl p-8 shadow-lg border border-border mb-8"
        >
          <div className="flex items-center gap-3 mb-6">
            <Clock className="w-6 h-6 text-primary" />
            <h2>Today's Activities</h2>
          </div>

          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 + index * 0.05 }}
                className="flex items-center gap-4 p-5 rounded-2xl hover:bg-accent transition-all"
              >
                <div className={`w-14 h-14 rounded-2xl ${activity.color} text-white flex items-center justify-center text-[1.5rem] shadow-lg`}>
                  {activity.icon}
                </div>
                <div className="flex-1">
                  <p className="text-[0.9375rem]">{activity.activity}</p>
                  <p className="text-[0.875rem] text-muted-foreground flex items-center gap-1 mt-1">
                    <Clock className="w-3 h-3" />
                    {activity.time}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="grid md:grid-cols-2 gap-6"
        >
          <Link to="/messages">
            <div className="bg-gradient-to-br from-primary to-secondary text-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all cursor-pointer">
              <MessageCircle className="w-12 h-12 mb-4" />
              <h3 className="text-[1.5rem] mb-2">Message Teacher</h3>
              <p className="text-[1rem] opacity-90">Have questions? Send a message to Mrs. Anderson</p>
              <div className="mt-6 inline-flex items-center gap-2 text-[0.9375rem]">
                View Messages
                <span>→</span>
              </div>
            </div>
          </Link>

          <div className="bg-gradient-to-br from-secondary to-[#22C55E]/70 text-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all cursor-pointer">
            <Award className="w-12 h-12 mb-4" />
            <h3 className="text-[1.5rem] mb-2">View Full Report</h3>
            <p className="text-[1rem] opacity-90">See detailed progress and achievements</p>
            <div className="mt-6 inline-flex items-center gap-2 text-[0.9375rem]">
              Open Report
              <span>→</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
