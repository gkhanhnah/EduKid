import { useState } from "react";
import { Sidebar } from "../components/Sidebar";
import { Sparkles, Wand2, BookOpen, FileText } from "lucide-react";
import { motion } from "motion/react";

interface LessonPlan {
  topic: string;
  objective: string;
  slides: {
    title: string;
    content: string;
  }[];
  exercises: {
    type: string;
    question: string;
  }[];
}

export function AILessonGenerator() {
  const [topic, setTopic] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [lessonPlan, setLessonPlan] = useState<LessonPlan | null>(null);

  const handleGenerate = () => {
    if (!topic.trim()) return;

    setIsGenerating(true);
    
    // Simulate AI generation
    setTimeout(() => {
      const mockLesson: LessonPlan = {
        topic: topic,
        objective: `To help Grade 1 students understand and learn about ${topic}`,
        slides: [
          {
            title: `Introduction to ${topic}`,
            content: `Let's explore the wonderful world of ${topic}! This lesson will help you understand the basics in a fun and engaging way.`
          },
          {
            title: 'Main Concepts',
            content: `Here are the key things to remember about ${topic}. We'll use pictures, songs, and games to help you learn!`
          },
          {
            title: 'Practice Time',
            content: `Now it's your turn! Let's practice what we've learned with some fun activities.`
          },
          {
            title: 'Review & Wrap Up',
            content: `Great job! Let's review what we learned today about ${topic}.`
          }
        ],
        exercises: [
          {
            type: 'Drawing',
            question: `Draw a picture about ${topic}`
          },
          {
            type: 'Matching',
            question: `Match the items related to ${topic}`
          },
          {
            type: 'Quiz',
            question: `Answer simple questions about ${topic}`
          }
        ]
      };

      setLessonPlan(mockLesson);
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="mb-2 flex items-center gap-3">
              <Sparkles className="w-10 h-10 text-[#8B5CF6]" />
              AI Lesson Generator
            </h1>
            <p className="text-[1.125rem] text-muted-foreground">
              Generate engaging lesson plans for Grade 1 students in seconds
            </p>
          </div>

          {/* Input Section */}
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-border mb-8">
            <div className="mb-6">
              <label htmlFor="topic" className="block mb-3 text-foreground">
                What topic would you like to teach?
              </label>
              <input
                id="topic"
                type="text"
                placeholder="e.g., Letter A, Numbers 1-10, Colors, Shapes..."
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full px-6 py-5 bg-input-background border-2 border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-[1.125rem]"
                onKeyPress={(e) => e.key === 'Enter' && handleGenerate()}
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={!topic.trim() || isGenerating}
              className="w-full md:w-auto bg-gradient-to-r from-[#8B5CF6] to-primary text-white px-8 py-5 rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    <Wand2 className="w-6 h-6" />
                  </motion.div>
                  Generating Lesson...
                </>
              ) : (
                <>
                  <Sparkles className="w-6 h-6" />
                  Generate Lesson Plan
                </>
              )}
            </button>
          </div>

          {/* Suggestions */}
          {!lessonPlan && (
            <div className="bg-white rounded-3xl p-8 shadow-lg border border-border">
              <h3 className="mb-6 flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-primary" />
                Popular Topics
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {[
                  { topic: 'Letter A', icon: '🅰️' },
                  { topic: 'Numbers 1-10', icon: '🔢' },
                  { topic: 'Colors', icon: '🎨' },
                  { topic: 'Shapes', icon: '🔷' },
                  { topic: 'Animals', icon: '🦁' },
                  { topic: 'Family', icon: '👨‍👩‍👧' },
                  { topic: 'Weather', icon: '🌦️' },
                  { topic: 'Fruits', icon: '🍎' },
                ].map((item) => (
                  <motion.button
                    key={item.topic}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setTopic(item.topic)}
                    className="p-6 rounded-2xl bg-accent hover:bg-primary hover:text-white transition-all text-center"
                  >
                    <div className="text-[3rem] mb-2">{item.icon}</div>
                    <div className="text-[0.9375rem]">{item.topic}</div>
                  </motion.button>
                ))}
              </div>
            </div>
          )}

          {/* Generated Lesson Plan */}
          {lessonPlan && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Objective */}
              <div className="bg-gradient-to-r from-[#8B5CF6] to-primary text-white rounded-3xl p-8 shadow-lg">
                <h3 className="mb-3">Lesson Objective</h3>
                <p className="text-[1.125rem] opacity-95">{lessonPlan.objective}</p>
              </div>

              {/* Slides Preview */}
              <div className="bg-white rounded-3xl p-8 shadow-lg border border-border">
                <h3 className="mb-6 flex items-center gap-2">
                  <FileText className="w-6 h-6 text-primary" />
                  Lesson Slides ({lessonPlan.slides.length})
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  {lessonPlan.slides.map((slide, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      className="p-6 rounded-2xl bg-gradient-to-br from-[#E0E7FF] to-[#FEF3C7] border-2 border-primary/20"
                    >
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-[0.875rem]">
                          {index + 1}
                        </div>
                        <h4 className="flex-1">{slide.title}</h4>
                      </div>
                      <p className="text-[0.9375rem] text-muted-foreground">{slide.content}</p>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Suggested Exercises */}
              <div className="bg-white rounded-3xl p-8 shadow-lg border border-border">
                <h3 className="mb-6 flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-[#F59E0B]" />
                  Suggested Exercises
                </h3>
                <div className="space-y-4">
                  {lessonPlan.exercises.map((exercise, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + index * 0.1 }}
                      className="flex items-start gap-4 p-6 rounded-2xl bg-accent hover:bg-primary/5 transition-all"
                    >
                      <div className="p-3 bg-white rounded-2xl shadow-md">
                        {exercise.type === 'Drawing' && <span className="text-[2rem]">✏️</span>}
                        {exercise.type === 'Matching' && <span className="text-[2rem]">🔗</span>}
                        {exercise.type === 'Quiz' && <span className="text-[2rem]">❓</span>}
                      </div>
                      <div className="flex-1">
                        <h4 className="mb-2">{exercise.type} Activity</h4>
                        <p className="text-[0.9375rem] text-muted-foreground">{exercise.question}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <button className="flex-1 bg-primary text-white px-6 py-5 rounded-2xl shadow-lg hover:shadow-xl transition-all">
                  Export as PDF
                </button>
                <button className="flex-1 bg-secondary text-white px-6 py-5 rounded-2xl shadow-lg hover:shadow-xl transition-all">
                  Share with Parents
                </button>
                <button
                  onClick={() => {
                    setLessonPlan(null);
                    setTopic("");
                  }}
                  className="bg-muted text-foreground px-6 py-5 rounded-2xl hover:bg-muted/70 transition-all"
                >
                  Generate New
                </button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
