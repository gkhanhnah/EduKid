import { Sidebar } from "../components/Sidebar";
import { Users, TrendingUp, Heart, Star, Calendar, Clock } from "lucide-react";
import { students } from "../data/mockData";
import { motion } from "motion/react";
import { Link } from "react-router";

export function TeacherDashboard() {
  const presentStudents = students.filter(s => s.status === 'present').length;
  const totalStudents = students.length;
  
  const quickActions = [
    { label: 'Take Attendance', icon: '✓', color: 'bg-secondary', path: '/students' },
    { label: 'Track Behavior', icon: '👍', color: 'bg-primary', path: '/behavior' },
    { label: 'Start Game', icon: '🎮', color: 'bg-[#F59E0B]', path: '/games' },
    { label: 'Generate Lesson', icon: '✨', color: 'bg-[#8B5CF6]', path: '/ai-lesson' },
  ];

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="mb-2">Good Morning, Mrs. Anderson! 👋</h1>
            <p className="text-[1.125rem] text-muted-foreground">
              Here's what's happening in your classroom today
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-primary/10 rounded-2xl">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <span className="text-[0.875rem] text-secondary">+2 today</span>
              </div>
              <h3 className="text-[2rem] mb-1">{presentStudents}/{totalStudents}</h3>
              <p className="text-[0.9375rem] text-muted-foreground">Students Present</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-secondary/10 rounded-2xl">
                  <TrendingUp className="w-6 h-6 text-secondary" />
                </div>
                <span className="text-[0.875rem] text-secondary">+15%</span>
              </div>
              <h3 className="text-[2rem] mb-1">87%</h3>
              <p className="text-[0.9375rem] text-muted-foreground">Good Behavior</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-[#F59E0B]/10 rounded-2xl">
                  <Star className="w-6 h-6 text-[#F59E0B]" />
                </div>
                <span className="text-[0.875rem] text-secondary">Top!</span>
              </div>
              <h3 className="text-[2rem] mb-1">24</h3>
              <p className="text-[0.9375rem] text-muted-foreground">Active Students</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-[#EF4444]/10 rounded-2xl">
                  <Heart className="w-6 h-6 text-[#EF4444]" />
                </div>
                <span className="text-[0.875rem] text-muted-foreground">This week</span>
              </div>
              <h3 className="text-[2rem] mb-1">3</h3>
              <p className="text-[0.9375rem] text-muted-foreground">New Messages</p>
            </motion.div>
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <h2 className="mb-6">Quick Actions</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {quickActions.map((action, index) => (
                <Link key={action.label} to={action.path}>
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`${action.color} text-white rounded-3xl p-6 cursor-pointer shadow-lg hover:shadow-xl transition-all`}
                  >
                    <div className="text-[3rem] mb-3">{action.icon}</div>
                    <p className="text-[1rem]">{action.label}</p>
                  </motion.div>
                </Link>
              ))}
            </div>
          </div>

          {/* Today's Schedule */}
          <div className="grid md:grid-cols-2 gap-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center gap-3 mb-6">
                <Calendar className="w-6 h-6 text-primary" />
                <h3>Today's Schedule</h3>
              </div>
              <div className="space-y-4">
                {[
                  { time: '9:00 AM', activity: 'Morning Circle', icon: '🌅' },
                  { time: '10:00 AM', activity: 'Alphabet Learning', icon: '🔤' },
                  { time: '11:00 AM', activity: 'Number Games', icon: '🔢' },
                  { time: '12:00 PM', activity: 'Lunch Break', icon: '🍎' },
                  { time: '1:00 PM', activity: 'Story Time', icon: '📚' },
                  { time: '2:00 PM', activity: 'Art & Crafts', icon: '🎨' },
                ].map((item) => (
                  <div key={item.time} className="flex items-center gap-4 p-3 rounded-2xl hover:bg-accent transition-all">
                    <div className="text-[2rem]">{item.icon}</div>
                    <div className="flex-1">
                      <p className="text-[0.9375rem]">{item.activity}</p>
                      <p className="text-[0.875rem] text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {item.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Top Performers */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center gap-3 mb-6">
                <Star className="w-6 h-6 text-[#F59E0B]" />
                <h3>Top Performers This Week</h3>
              </div>
              <div className="space-y-4">
                {students.slice(0, 6).map((student, index) => (
                  <div key={student.id} className="flex items-center gap-4 p-3 rounded-2xl hover:bg-accent transition-all">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-[1.5rem]">
                      {student.avatar}
                    </div>
                    <div className="flex-1">
                      <p className="text-[0.9375rem]">{student.name}</p>
                      <div className="flex gap-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-[#F59E0B] text-[#F59E0B]" />
                        ))}
                      </div>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-[#F59E0B] text-white flex items-center justify-center text-[0.875rem]">
                      #{index + 1}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
