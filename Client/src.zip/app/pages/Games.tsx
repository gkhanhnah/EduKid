import { Sidebar } from "../components/Sidebar";
import { games } from "../data/mockData";
import { Trophy, Clock, Star } from "lucide-react";
import { motion } from "motion/react";
import { Link } from "react-router";

export function Games() {
  const getDifficultyStyle = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return { bg: 'bg-secondary/10', text: 'text-secondary', label: 'Easy' };
      case 'medium': return { bg: 'bg-[#F59E0B]/10', text: 'text-[#F59E0B]', label: 'Medium' };
      case 'hard': return { bg: 'bg-destructive/10', text: 'text-destructive', label: 'Hard' };
      default: return { bg: 'bg-muted', text: 'text-foreground', label: difficulty };
    }
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="mb-2">Game-Based Learning</h1>
            <p className="text-[1.125rem] text-muted-foreground">
              Fun and educational games for Grade 1 students
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-2xl">
                  <Trophy className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-[2rem] mb-1">{games.length}</h3>
                  <p className="text-[0.9375rem] text-muted-foreground">Available Games</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-secondary/10 rounded-2xl">
                  <Star className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h3 className="text-[2rem] mb-1">124</h3>
                  <p className="text-[0.9375rem] text-muted-foreground">Games Completed</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-[#F59E0B]/10 rounded-2xl">
                  <Clock className="w-6 h-6 text-[#F59E0B]" />
                </div>
                <div>
                  <h3 className="text-[2rem] mb-1">2.5h</h3>
                  <p className="text-[0.9375rem] text-muted-foreground">Total Play Time</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Games Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game, index) => {
              const difficultyStyle = getDifficultyStyle(game.difficulty);
              
              return (
                <motion.div
                  key={game.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  className="bg-white rounded-3xl shadow-lg border border-border overflow-hidden"
                >
                  {/* Game Icon/Header */}
                  <div 
                    className="h-40 flex items-center justify-center text-[5rem]"
                    style={{ backgroundColor: `${game.color}15` }}
                  >
                    {game.icon}
                  </div>

                  {/* Game Info */}
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="text-[1.125rem] flex-1">{game.title}</h3>
                      <div className={`px-3 py-1 rounded-full text-[0.75rem] ${difficultyStyle.bg} ${difficultyStyle.text}`}>
                        {difficultyStyle.label}
                      </div>
                    </div>
                    <p className="text-[0.9375rem] text-muted-foreground mb-6">
                      {game.description}
                    </p>

                    {/* Stats */}
                    <div className="flex gap-4 mb-6 pb-6 border-b border-border text-[0.875rem]">
                      <div className="flex items-center gap-2">
                        <Star className="w-4 h-4 text-[#F59E0B]" />
                        <span className="text-muted-foreground">4.8</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Trophy className="w-4 h-4 text-primary" />
                        <span className="text-muted-foreground">12 plays</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-secondary" />
                        <span className="text-muted-foreground">~10 min</span>
                      </div>
                    </div>

                    {/* Start Button */}
                    <Link to={`/games/${game.id}`}>
                      <button 
                        className="w-full py-4 rounded-2xl text-white shadow-lg hover:shadow-xl transition-all"
                        style={{ backgroundColor: game.color }}
                      >
                        Start Game
                      </button>
                    </Link>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Recent Activity */}
          <div className="mt-8 bg-white rounded-3xl p-6 shadow-lg border border-border">
            <h3 className="mb-6">Recent Game Activity</h3>
            <div className="space-y-4">
              {[
                { student: 'Emma Wilson', avatar: '👧', game: 'Alphabet Adventure', score: '100%', time: '10 mins ago' },
                { student: 'Liam Chen', avatar: '👦', game: 'Number Counting', score: '95%', time: '25 mins ago' },
                { student: 'Olivia Smith', avatar: '👧', game: 'Shape Matching', score: '88%', time: '1 hour ago' },
                { student: 'Noah Brown', avatar: '👦', game: 'Color Quiz', score: '92%', time: '2 hours ago' },
              ].map((activity, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="flex items-center gap-4 p-4 rounded-2xl hover:bg-accent transition-all"
                >
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-[1.5rem]">
                    {activity.avatar}
                  </div>
                  <div className="flex-1">
                    <p className="text-[0.9375rem]">{activity.student}</p>
                    <p className="text-[0.875rem] text-muted-foreground">Played {activity.game}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[0.9375rem] text-secondary">{activity.score}</p>
                    <p className="text-[0.875rem] text-muted-foreground">{activity.time}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
