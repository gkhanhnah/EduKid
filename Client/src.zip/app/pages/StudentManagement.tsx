import { useState } from "react";
import { Sidebar } from "../components/Sidebar";
import { students as initialStudents } from "../data/mockData";
import { Plus, Search } from "lucide-react";
import { motion } from "motion/react";

export function StudentManagement() {
  const [students] = useState(initialStudents);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="mb-2">Student Management</h1>
              <p className="text-[1.125rem] text-muted-foreground">
                Manage your Grade 1 classroom students
              </p>
            </div>
            <button className="bg-primary text-white px-6 py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center gap-2 w-fit">
              <Plus className="w-5 h-5" />
              Add Student
            </button>
          </div>

          {/* Search */}
          <div className="mb-8">
            <div className="relative max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-white border border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-3xl p-6 shadow-lg border border-border">
              <div className="text-[2rem] mb-2">👥</div>
              <h3 className="text-[2rem] mb-1">{students.length}</h3>
              <p className="text-[0.9375rem] text-muted-foreground">Total Students</p>
            </div>
            <div className="bg-white rounded-3xl p-6 shadow-lg border border-border">
              <div className="text-[2rem] mb-2">✅</div>
              <h3 className="text-[2rem] mb-1 text-secondary">
                {students.filter(s => s.status === 'present').length}
              </h3>
              <p className="text-[0.9375rem] text-muted-foreground">Present Today</p>
            </div>
            <div className="bg-white rounded-3xl p-6 shadow-lg border border-border">
              <div className="text-[2rem] mb-2">❌</div>
              <h3 className="text-[2rem] mb-1 text-destructive">
                {students.filter(s => s.status === 'absent').length}
              </h3>
              <p className="text-[0.9375rem] text-muted-foreground">Absent Today</p>
            </div>
          </div>

          {/* Student Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredStudents.map((student, index) => (
              <motion.div
                key={student.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ scale: 1.05 }}
                className="bg-white rounded-3xl p-6 shadow-lg border border-border cursor-pointer hover:shadow-xl transition-all"
              >
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-[3rem] mb-4 shadow-lg">
                    {student.avatar}
                  </div>
                  <h4 className="mb-2">{student.name}</h4>
                  <div className={`px-4 py-2 rounded-full text-[0.875rem] ${
                    student.status === 'present'
                      ? 'bg-secondary/10 text-secondary'
                      : 'bg-destructive/10 text-destructive'
                  }`}>
                    {student.status === 'present' ? '✓ Present' : '✗ Absent'}
                  </div>
                </div>
                <div className="mt-6 pt-6 border-t border-border">
                  <div className="flex justify-between text-center">
                    <div>
                      <div className="text-[1.5rem] text-secondary">👍</div>
                      <div className="text-[0.75rem] text-muted-foreground mt-1">Good</div>
                      <div className="text-[0.875rem]">8</div>
                    </div>
                    <div>
                      <div className="text-[1.5rem] text-primary">⭐</div>
                      <div className="text-[0.75rem] text-muted-foreground mt-1">Active</div>
                      <div className="text-[0.875rem]">12</div>
                    </div>
                    <div>
                      <div className="text-[1.5rem] text-destructive">👎</div>
                      <div className="text-[0.75rem] text-muted-foreground mt-1">Bad</div>
                      <div className="text-[0.875rem]">2</div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
