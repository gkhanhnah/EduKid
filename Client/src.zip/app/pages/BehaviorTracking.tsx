import { useState } from "react";
import { Sidebar } from "../components/Sidebar";
import { students as initialStudents } from "../data/mockData";
import { motion } from "motion/react";
import confetti from "canvas-confetti";

interface BehaviorCount {
  good: number;
  bad: number;
  sleepy: number;
  active: number;
}

export function BehaviorTracking() {
  const [students] = useState(initialStudents);
  const [behaviorCounts, setBehaviorCounts] = useState<Record<string, BehaviorCount>>({});
  const [lastAction, setLastAction] = useState<{ studentId: string; type: string } | null>(null);

  const handleBehaviorClick = (studentId: string, type: 'good' | 'bad' | 'sleepy' | 'active') => {
    setBehaviorCounts(prev => ({
      ...prev,
      [studentId]: {
        good: (prev[studentId]?.good || 0) + (type === 'good' ? 1 : 0),
        bad: (prev[studentId]?.bad || 0) + (type === 'bad' ? 1 : 0),
        sleepy: (prev[studentId]?.sleepy || 0) + (type === 'sleepy' ? 1 : 0),
        active: (prev[studentId]?.active || 0) + (type === 'active' ? 1 : 0),
      }
    }));

    setLastAction({ studentId, type });

    // Trigger confetti for good and active behaviors
    if (type === 'good' || type === 'active') {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 }
      });
    }

    // Clear animation after a short delay
    setTimeout(() => setLastAction(null), 1000);
  };

  const totalGood = Object.values(behaviorCounts).reduce((sum, counts) => sum + counts.good, 0);
  const totalBad = Object.values(behaviorCounts).reduce((sum, counts) => sum + counts.bad, 0);
  const totalSleepy = Object.values(behaviorCounts).reduce((sum, counts) => sum + counts.sleepy, 0);
  const totalActive = Object.values(behaviorCounts).reduce((sum, counts) => sum + counts.active, 0);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="mb-2">Behavior Tracking</h1>
            <p className="text-[1.125rem] text-muted-foreground">
              Track student behavior in real-time with one-click actions
            </p>
          </div>

          {/* Today's Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="text-[2.5rem] mb-2">👍</div>
              <h3 className="text-[2rem] mb-1 text-secondary">{totalGood}</h3>
              <p className="text-[0.9375rem] text-muted-foreground">Good Behaviors</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="text-[2.5rem] mb-2">⭐</div>
              <h3 className="text-[2rem] mb-1 text-primary">{totalActive}</h3>
              <p className="text-[0.9375rem] text-muted-foreground">Active Students</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="text-[2.5rem] mb-2">😴</div>
              <h3 className="text-[2rem] mb-1 text-[#F59E0B]">{totalSleepy}</h3>
              <p className="text-[0.9375rem] text-muted-foreground">Sleepy/Tired</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-border"
            >
              <div className="text-[2.5rem] mb-2">👎</div>
              <h3 className="text-[2rem] mb-1 text-destructive">{totalBad}</h3>
              <p className="text-[0.9375rem] text-muted-foreground">Needs Attention</p>
            </motion.div>
          </div>

          {/* Student Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {students.filter(s => s.status === 'present').map((student, index) => {
              const counts = behaviorCounts[student.id] || { good: 0, bad: 0, sleepy: 0, active: 0 };
              const isAnimating = lastAction?.studentId === student.id;
              
              return (
                <motion.div
                  key={student.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-3xl p-6 shadow-lg border border-border"
                >
                  {/* Student Info */}
                  <div className="flex items-center gap-4 mb-6 pb-6 border-b border-border">
                    <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-[2.5rem] shadow-lg">
                      {student.avatar}
                    </div>
                    <div className="flex-1">
                      <h4>{student.name}</h4>
                      <div className="flex gap-2 mt-2">
                        <div className="text-[0.875rem] text-secondary flex items-center gap-1">
                          <span>👍</span> {counts.good}
                        </div>
                        <div className="text-[0.875rem] text-primary flex items-center gap-1">
                          <span>⭐</span> {counts.active}
                        </div>
                        <div className="text-[0.875rem] text-[#F59E0B] flex items-center gap-1">
                          <span>😴</span> {counts.sleepy}
                        </div>
                        <div className="text-[0.875rem] text-destructive flex items-center gap-1">
                          <span>👎</span> {counts.bad}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Behavior Buttons */}
                  <div className="grid grid-cols-2 gap-3">
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      animate={isAnimating && lastAction?.type === 'good' ? { scale: [1, 1.1, 1] } : {}}
                      onClick={() => handleBehaviorClick(student.id, 'good')}
                      className="bg-secondary hover:bg-secondary/90 text-white p-5 rounded-2xl transition-all shadow-lg hover:shadow-xl"
                    >
                      <div className="text-[2rem] mb-2">👍</div>
                      <div className="text-[0.9375rem]">Good</div>
                    </motion.button>

                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      animate={isAnimating && lastAction?.type === 'bad' ? { scale: [1, 1.1, 1] } : {}}
                      onClick={() => handleBehaviorClick(student.id, 'bad')}
                      className="bg-destructive hover:bg-destructive/90 text-white p-5 rounded-2xl transition-all shadow-lg hover:shadow-xl"
                    >
                      <div className="text-[2rem] mb-2">👎</div>
                      <div className="text-[0.9375rem]">Bad</div>
                    </motion.button>

                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      animate={isAnimating && lastAction?.type === 'sleepy' ? { scale: [1, 1.1, 1] } : {}}
                      onClick={() => handleBehaviorClick(student.id, 'sleepy')}
                      className="bg-[#F59E0B] hover:bg-[#F59E0B]/90 text-white p-5 rounded-2xl transition-all shadow-lg hover:shadow-xl"
                    >
                      <div className="text-[2rem] mb-2">😴</div>
                      <div className="text-[0.9375rem]">Sleepy</div>
                    </motion.button>

                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      animate={isAnimating && lastAction?.type === 'active' ? { scale: [1, 1.1, 1] } : {}}
                      onClick={() => handleBehaviorClick(student.id, 'active')}
                      className="bg-primary hover:bg-primary/90 text-white p-5 rounded-2xl transition-all shadow-lg hover:shadow-xl"
                    >
                      <div className="text-[2rem] mb-2">⭐</div>
                      <div className="text-[0.9375rem]">Active</div>
                    </motion.button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
