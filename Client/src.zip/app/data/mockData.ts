export interface Student {
  id: string;
  name: string;
  avatar: string;
  status: 'present' | 'absent';
  behaviors: BehaviorRecord[];
}

export interface BehaviorRecord {
  id: string;
  studentId: string;
  studentName: string;
  type: 'good' | 'bad' | 'sleepy' | 'active';
  timestamp: Date;
  note?: string;
}

export const students: Student[] = [
  { id: '1', name: 'Emma Wilson', avatar: '👧', status: 'present', behaviors: [] },
  { id: '2', name: 'Liam Chen', avatar: '👦', status: 'present', behaviors: [] },
  { id: '3', name: 'Olivia Smith', avatar: '👧', status: 'present', behaviors: [] },
  { id: '4', name: 'Noah Brown', avatar: '👦', status: 'present', behaviors: [] },
  { id: '5', name: 'Ava Martinez', avatar: '👧', status: 'absent', behaviors: [] },
  { id: '6', name: 'Lucas Davis', avatar: '👦', status: 'present', behaviors: [] },
  { id: '7', name: 'Sophia Garcia', avatar: '👧', status: 'present', behaviors: [] },
  { id: '8', name: 'Mason Lee', avatar: '👦', status: 'present', behaviors: [] },
  { id: '9', name: 'Isabella Taylor', avatar: '👧', status: 'present', behaviors: [] },
  { id: '10', name: 'Ethan White', avatar: '👦', status: 'present', behaviors: [] },
  { id: '11', name: 'Mia Johnson', avatar: '👧', status: 'present', behaviors: [] },
  { id: '12', name: 'James Anderson', avatar: '👦', status: 'present', behaviors: [] },
];

export interface Game {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  icon: string;
  color: string;
}

export const games: Game[] = [
  {
    id: 'alphabet',
    title: 'Alphabet Adventure',
    description: 'Learn letters A-Z with fun animations',
    difficulty: 'easy',
    icon: '🔤',
    color: '#4F46E5',
  },
  {
    id: 'counting',
    title: 'Number Counting',
    description: 'Count from 1 to 20 with cute animals',
    difficulty: 'easy',
    icon: '🔢',
    color: '#22C55E',
  },
  {
    id: 'matching',
    title: 'Shape Matching',
    description: 'Match shapes and colors together',
    difficulty: 'medium',
    icon: '🔷',
    color: '#F59E0B',
  },
  {
    id: 'colors',
    title: 'Color Quiz',
    description: 'Identify different colors',
    difficulty: 'easy',
    icon: '🎨',
    color: '#8B5CF6',
  },
  {
    id: 'animals',
    title: 'Animal Sounds',
    description: 'Learn animal names and sounds',
    difficulty: 'easy',
    icon: '🦁',
    color: '#EF4444',
  },
  {
    id: 'words',
    title: 'Word Builder',
    description: 'Build simple 3-letter words',
    difficulty: 'medium',
    icon: '📝',
    color: '#06B6D4',
  },
];

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  senderType: 'teacher' | 'parent';
  receiverId: string;
  receiverName: string;
  content: string;
  timestamp: Date;
  read: boolean;
}

export interface Conversation {
  id: string;
  participantName: string;
  participantType: 'teacher' | 'parent';
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  avatar: string;
}

export const conversations: Conversation[] = [
  {
    id: '1',
    participantName: 'Mrs. Sarah Johnson (Emma\'s Mom)',
    participantType: 'parent',
    lastMessage: 'Thank you for the update on Emma\'s progress!',
    lastMessageTime: new Date(2026, 2, 22, 10, 30),
    unreadCount: 0,
    avatar: '👩',
  },
  {
    id: '2',
    participantName: 'Mr. David Chen (Liam\'s Dad)',
    participantType: 'parent',
    lastMessage: 'Can we schedule a meeting to discuss Liam\'s behavior?',
    lastMessageTime: new Date(2026, 2, 21, 14, 15),
    unreadCount: 2,
    avatar: '👨',
  },
  {
    id: '3',
    participantName: 'Ms. Maria Garcia (Sophia\'s Mom)',
    participantType: 'parent',
    lastMessage: 'Sophia loved the alphabet game today!',
    lastMessageTime: new Date(2026, 2, 20, 16, 45),
    unreadCount: 0,
    avatar: '👩',
  },
];
